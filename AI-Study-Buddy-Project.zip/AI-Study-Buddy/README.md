# AI Study Buddy

AI Study Buddy is a simple AI-powered tool that helps students understand study notes.

## Features
- Generate summaries of study notes
- Automatically create quiz questions
- Simple web interface using Streamlit

## Technologies Used
- Python
- Streamlit
- Hugging Face Transformers

## How to Run

1. Install dependencies:
pip install -r requirements.txt

2. Run the application:
streamlit run app.py

Then open the link shown in the terminal.