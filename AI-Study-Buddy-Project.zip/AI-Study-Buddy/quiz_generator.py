import random

def generate_quiz(text):
    sentences = text.split(".")
    questions = []

    for s in sentences[:5]:
        words = s.split()
        if len(words) > 5:
            blank_index = random.randint(1, len(words)-2)
            answer = words[blank_index]
            words[blank_index] = "_____"
            question = " ".join(words)

            questions.append({
                "question": question,
                "answer": answer
            })

    return questions