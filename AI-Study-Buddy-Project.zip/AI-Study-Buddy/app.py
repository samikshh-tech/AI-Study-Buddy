import streamlit as st
from summarizer import generate_summary
from quiz_generator import generate_quiz

st.title("📚 AI Study Buddy")

st.write("Paste your study notes below to generate a summary and quiz.")

text = st.text_area("Enter your study notes")

if st.button("Generate Summary"):
    if text.strip() == "":
        st.warning("Please enter some notes first.")
    else:
        summary = generate_summary(text)
        st.subheader("Summary")
        st.write(summary)

if st.button("Generate Quiz"):
    if text.strip() == "":
        st.warning("Please enter some notes first.")
    else:
        quiz = generate_quiz(text)

        st.subheader("Quiz Questions")

        for q in quiz:
            st.write("Q:", q["question"])
            st.write("Answer:", q["answer"])
            st.write("---")